import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

// Import screens
import SplashScreen from './src/SplashScreen';
import Onboarding from './src/Onboarding';
import SignupScreen from './src/SignupScreen';
import DashboardScreen from './src/Dashboard';
import PatientDetailsScreen from './src/PatientDetailsScreen';
import AnalyticsScreen from './src/AnalyticsScreen';
import SettingsScreen from './src/Settings';
import ToolsScreen from './src/ToolsScreen';

// Import the new sections/screens
import AlertsSection from './src/AlertsSection';
import DailySummary from './src/DailySummary';
import MedicationAdherence from './src/MedicationAdherence';
import MedicationReminder from './src/MedicationReminder';
import RealTimeMonitoring from './src/Real-TimeMonitoring';
import VitalsSection from './src/VitalsSection';
import Setup from './src/Setup';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Bottom Tab Navigator
const TabNavigator = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName;
        if (route.name === 'Dashboard') {
          iconName = focused ? 'home' : 'home-outline';
        } else if (route.name === 'Patient Details') {
          iconName = focused ? 'person-circle' : 'person-circle-outline';
        } else if (route.name === 'Analytics') {
          iconName = focused ? 'stats-chart' : 'stats-chart-outline';
        } else if (route.name === 'Settings') {
          iconName = focused ? 'settings' : 'settings-outline';
        } else if (route.name === 'Tools') {
          iconName = focused ? 'construct' : 'construct-outline';
        }
        return <Ionicons name={iconName} size={size} color={color} />;
      },
      tabBarActiveTintColor: '#4CAF50',
      tabBarInactiveTintColor: 'gray',
    })}
  >
    <Tab.Screen name="Dashboard" component={DashboardScreen} />
    <Tab.Screen name="Tools" component={ToolsScreen} />
    <Tab.Screen name="Analytics" component={AnalyticsScreen} />
    <Tab.Screen name="Settings" component={SettingsScreen} />
    <Tab.Screen name="Patient Details" component={PatientDetailsScreen} />
  </Tab.Navigator>
);

// Main App Component
const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000); // Simulating splash screen timeout

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator>
  
        <Stack.Screen 
          name="Splash" 
          component={SplashScreen} 
          options={{ headerShown: false }} // Show header for SplashScreen
        />
        <Stack.Screen 
          name="Onboarding" 
          component={Onboarding} 
          options={{ headerShown: false }} // Show header for Onboarding
        />
        <Stack.Screen 
          name="SignupScreen" 
          component={SignupScreen} 
          options={{ headerShown: false}} // Show header for SignupScreen
        />
         <Stack.Screen 
          name="Setup" 
          component={Setup} 
          options={{ headerShown: false}} // Show header for SignupScreen
        />
        <Stack.Screen 
          name="MainTabs" 
          component={TabNavigator} 
          options={{ headerShown: false }} // Hide header for MainTabs
        />

        {/* Add the new screens here */}
        <Stack.Screen 
          name="AlertsSection" 
          component={AlertsSection} 
          options={{ title: '', headerShown: true }} // Show header for AlertsSection
        />
        <Stack.Screen 
          name="DailySummary" 
          component={DailySummary} 
          options={{ title: '', headerShown: true }} // Show header for DailySummary
        />
        <Stack.Screen 
          name="MedicationAdherence" 
          component={MedicationAdherence} 
          options={{ title: '', headerShown: true }} // Show header for MedicationAdherence
        />
        <Stack.Screen 
          name="MedicationReminder" 
          component={MedicationReminder} 
          options={{ title: '', headerShown: true }} // Show header for MedicationReminder
        />
        <Stack.Screen 
          name="RealTimeMonitoring" 
          component={RealTimeMonitoring} 
          options={{ title: '', headerShown: true }} // Show header for RealTimeMonitoring
        />
        <Stack.Screen 
          name="VitalsSection" 
          component={VitalsSection} 
          options={{ title: '', headerShown: true }} // Show header for VitalsSection
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

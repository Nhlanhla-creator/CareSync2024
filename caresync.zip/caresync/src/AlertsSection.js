import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,SafeAreaView } from 'react-native';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';

const AlertsSection = () => {
 
  const [alerts, setAlerts] = useState([
    { id: '1', message: 'Heart rate exceeded safe limits (110 bpm)', time: '10:15 AM', type: 'critical' },
    { id: '2', message: 'Missed medication: Metformin', time: '12:30 PM', type: 'medication' },
    { id: '3', message: 'Oxygen level dropped to 89%', time: '2:00 PM', type: 'critical' },
  ]);


  const dismissAlert = (id) => {
    setAlerts((prevAlerts) => prevAlerts.filter((alert) => alert.id !== id));
    Alert.alert('Alert Dismissed', 'The alert has been successfully dismissed.');
  };

  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.container}>
      <Text style={styles.title}>Alerts</Text>

  
      <FlatList
        data={alerts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View
            style={[
              styles.alertCard,
              item.type === 'critical' && styles.criticalAlert,
              item.type === 'medication' && styles.medicationAlert,
            ]}
          >
            <View style={styles.alertContent}>
              <FontAwesome
                name={item.type === 'critical' ? 'heartbeat' : 'pills'}
                size={24}
                color="#FFF"
              />
              <View style={styles.alertTextContainer}>
                <Text style={styles.alertMessage}>{item.message}</Text>
                <Text style={styles.alertTime}>{item.time}</Text>
              </View>
            </View>
            <TouchableOpacity
              style={styles.dismissButton}
              onPress={() => dismissAlert(item.id)}
            >
              <MaterialIcons name="clear" size={20} color="#FFF" />
            </TouchableOpacity>
          </View>
        )}
      />

  
      {alerts.length === 0 && (
        <View style={styles.noAlertsContainer}>
          <Text style={styles.noAlertsText}>No active alerts. All vitals are normal!</Text>
        </View>
      )}
    </View>
     </SafeAreaView>
  );
};

export default AlertsSection;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDE7F6', 
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6A1B9A', 
    marginBottom: 20,
    textAlign: 'center',
  },
  alertCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#B39DDB', 
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  criticalAlert: {
    backgroundColor: '#E57373', 
  },
  medicationAlert: {
    backgroundColor: '#4FC3F7', 
  },
  alertContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  alertTextContainer: {
    marginLeft: 10,
  },
  alertMessage: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
  alertTime: {
    fontSize: 12,
    color: '#FFF',
    marginTop: 5,
  },
  dismissButton: {
    backgroundColor: '#6A1B9A', 
    borderRadius: 8,
    padding: 8,
  },
  noAlertsContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  noAlertsText: {
    fontSize: 16,
    color: '#757575', 
  },
});

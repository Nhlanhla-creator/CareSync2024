import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  Alert, 
  TextInput, 
  Modal ,SafeAreaView
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const MedicationAdherence = () => {

  const [medications, setMedications] = useState([
    { id: '1', name: 'Aspirin', time: '8:00 AM', status: 'Pending' },
    { id: '2', name: 'Metformin', time: '12:00 PM', status: 'Pending' },
    { id: '3', name: 'Vitamin D', time: '6:00 PM', status: 'Pending' },
  ]);


  const [modalVisible, setModalVisible] = useState(false);
  const [newMedication, setNewMedication] = useState({ name: '', time: '' });


  const updateStatus = (id, status) => {
    setMedications((prevMedications) =>
      prevMedications.map((med) =>
        med.id === id ? { ...med, status } : med
      )
    );
    Alert.alert('Status Updated', `Medication marked as ${status}.`);
  };

  const addMedication = () => {
    if (!newMedication.name || !newMedication.time) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }
    setMedications((prevMedications) => [
      ...prevMedications,
      { id: Date.now().toString(), ...newMedication, status: 'Pending' },
    ]);
    setNewMedication({ name: '', time: '' });
    setModalVisible(false);
    Alert.alert('Success', 'New medication added.');
  };

  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.container}>
      <Text style={styles.title}>Medication Adherence</Text>

 
      <FlatList
        data={medications}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.medicationCard}>
            <View style={styles.medicationInfo}>
              <Text style={styles.medicationName}>{item.name}</Text>
              <Text style={styles.medicationTime}>{item.time}</Text>
            </View>
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[styles.button, styles.takenButton]}
                onPress={() => updateStatus(item.id, 'Taken')}
              >
                <FontAwesome name="check" size={20} color="#FFF" />
                <Text style={styles.buttonText}>Taken</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.skippedButton]}
                onPress={() => updateStatus(item.id, 'Skipped')}
              >
                <FontAwesome name="times" size={20} color="#FFF" />
                <Text style={styles.buttonText}>Skipped</Text>
              </TouchableOpacity>
            </View>
            <Text
              style={[
                styles.statusText,
                item.status === 'Taken' && styles.statusTaken,
                item.status === 'Skipped' && styles.statusSkipped,
              ]}
            >
              {item.status}
            </Text>
          </View>
        )}
      />


      <TouchableOpacity
        style={styles.addButton}
        onPress={() => setModalVisible(true)}
      >
        <FontAwesome name="plus" size={20} color="#FFF" />
        <Text style={styles.addButtonText}>Add Medication</Text>
      </TouchableOpacity>

      <Modal
        transparent={true}
        visible={modalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Medication</Text>
            <TextInput
              style={styles.input}
              placeholder="Medication Name"
              value={newMedication.name}
              onChangeText={(text) => setNewMedication({ ...newMedication, name: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Time (e.g., 8:00 AM)"
              value={newMedication.time}
              onChangeText={(text) => setNewMedication({ ...newMedication, time: text })}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={addMedication}
              >
                <Text style={styles.modalButtonText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
     </SafeAreaView>
  );
};

export default MedicationAdherence;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDE7F6', 
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6A1B9A', 
    marginBottom: 20,
    textAlign: 'center',
  },
  medicationCard: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    elevation: 3,
  },
  medicationInfo: {
    marginBottom: 10,
  },
  medicationName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4A148C', 
  },
  medicationTime: {
    fontSize: 14,
    color: '#757575', 
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    width: '45%',
  },
  takenButton: {
    backgroundColor: '#4CAF50', 
  },
  skippedButton: {
    backgroundColor: '#F44336', 
  },
  buttonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  statusText: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 5,
  },
  statusTaken: {
    color: '#4CAF50', 
  },
  statusSkipped: {
    color: '#F44336', 
  },
  addButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#6A1B9A', 
    borderRadius: 8,
    padding: 15,
    marginTop: 20,
  },
  addButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    color: '#6A1B9A',
  },
  input: {
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    padding: 10,
    borderRadius: 8,
    width: '45%',
    alignItems: 'center',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  cancelButton: {
    backgroundColor: '#F44336',
  },
  modalButtonText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
});

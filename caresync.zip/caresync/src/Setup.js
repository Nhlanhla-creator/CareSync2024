import React, { useState, useEffect } from 'react';
import { View, Text, Button, ActivityIndicator, Alert, Platform, StyleSheet } from 'react-native';
import { PermissionsAndroid } from 'react-native';
import AppleHealthKit from 'react-native-health';
import GoogleFit from 'react-native-google-fit'; 
import { useNavigation } from '@react-navigation/native';

const Setup = () => {
  const navigation = useNavigation();
  const [isHealthDataAvailable, setIsHealthDataAvailable] = useState(false);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);


  const requestAndroidPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        {
          title: 'Bluetooth Permission',
          message:
            'We need your permission to connect to Bluetooth and fetch health data from your smartwatch.',
          buttonPositive: 'OK',
        }
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('Bluetooth permission granted');
      } else {
        Alert.alert('Permission Denied', 'Bluetooth permission is required to connect to your smartwatch.');
      }
    } catch (err) {
      console.warn(err);
      Alert.alert('Error', 'An error occurred while requesting permissions.');
    }
  };

  
  const initializeAppleHealthKit = async () => {
    const options = {
      permissions: {
        read: ['HeartRate', 'Steps', 'BloodPressure', 'OxygenSaturation'],
      },
    };

    AppleHealthKit.initHealthKit(options, (err) => {
      if (err) {
        Alert.alert('Error', 'Error initializing Apple HealthKit. Please try again.');
        setLoading(false);
        return;
      }
      console.log('Apple HealthKit initialized');
      setIsHealthDataAvailable(true);
      setLoading(false);
    });
  };


  const initializeGoogleFit = () => {
    const options = {
      scopes: ['fitness.activity.read', 'fitness.body.read', 'fitness.location.read'],
    };

    GoogleFit.startFitnessServices()
      .then(() => {
        console.log('Google Fit services started');
        setIsHealthDataAvailable(true);
        setLoading(false);
      })
      .catch(() => {
        Alert.alert('Error', 'Error initializing Google Fit. Please try again.');
        setLoading(false);
      });
  };

  useEffect(() => {
    if (Platform.OS === 'ios') {
      setStep(1);
    } else if (Platform.OS === 'android') {
      setStep(1);
      requestAndroidPermission().then(() => {
        setStep(2);
        initializeGoogleFit();
      });
    }
  }, []);

  const handleStartSetup = () => {
    setStep(1);
    setLoading(true);
    setTimeout(() => {
      setStep(2); 
      setTimeout(() => {
        setStep(3); 
        setLoading(false);
        setIsHealthDataAvailable(true);
        navigation.navigate('MainTabs');
      }, 3000); 
    }, 3000); 
  };

  const renderStep = () => {
    if (loading) {
      return (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#9B4DCA" />
          <Text style={styles.loadingText}>Please wait...</Text>
        </View>
      );
    }

    if (step === 1) {
      return (
        <View style={styles.centered}>
          <Text style={styles.stepText}>
            Step 1: Please turn on Bluetooth on your smartwatch and phone.
          </Text>
          <Button title="Proceed" onPress={handleStartSetup} color="#9B4DCA" />
        </View>
      );
    }

    if (step === 2) {
      return (
        <View style={styles.centered}>
          <Text style={styles.stepText}>
            Step 2: Connecting to your smartwatch...
          </Text>
        </View>
      );
    }

    if (step === 3) {
      return (
        <View style={styles.centered}>
          <Text style={styles.successText}>
            Step 3: Your smartwatch is connected!
          </Text>
          <Button
            title="Start Tracking"
            onPress={() => Alert.alert('Ready to start tracking your health data!')}
            color="#9B4DCA"
          />
        </View>
      );
    }

    return (
      <Text style={styles.errorText}>
        Something went wrong. Please restart the setup process.
      </Text>
    );
  };

  return (
    <View style={styles.container}>
      {renderStep()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#F0E5FF',
  },
  centered: {
    alignItems: 'center',
  },
  stepText: {
    fontSize: 18,
    marginBottom: 20,
    color: '#9B4DCA',
    textAlign: 'center',
  },
  loadingText: {
    fontSize: 18,
    marginTop: 20,
    color: '#9B4DCA',
    textAlign: 'center',
  },
  successText: {
    fontSize: 18,
    marginBottom: 20,
    color: 'green',
    textAlign: 'center',
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    textAlign: 'center',
  },
});

export default Setup;

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList ,SafeAreaView} from 'react-native';
import { Calendar } from 'react-native-calendars';

const MedicationReminder = () => {
  const [medications, setMedications] = useState([
    { id: 1, name: 'Aspirin', time: '08:00 AM', taken: false },
    { id: 2, name: 'Vitamin D', time: '12:00 PM', taken: false },
    { id: 3, name: 'Ibuprofen', time: '06:00 PM', taken: false },
  ]);
  const [selectedDate, setSelectedDate] = useState('');


  const markAsTaken = (id) => {
    setMedications((prevState) =>
      prevState.map((med) => (med.id === id ? { ...med, taken: true } : med))
    );
  };

  return (
    <SafeAreaView style={styles.container}>
    <View style={styles.container}>
      <Text style={styles.header}>Medication Reminder</Text>

    
      <Calendar
        style={styles.calendar}
        markedDates={{
          [selectedDate]: { selected: true, selectedColor: '#9F7BBF' },
        }}
        onDayPress={(day) => setSelectedDate(day.dateString)}
      />

 
      <FlatList
        data={medications}
        renderItem={({ item }) => (
          <View style={styles.medicationCard}>
            <Text style={styles.medicationName}>{item.name}</Text>
            <Text style={styles.medicationTime}>{item.time}</Text>
            <TouchableOpacity
              style={styles.reminderButton}
              onPress={() => markAsTaken(item.id)}
            >
              <Text style={styles.buttonText}>
                {item.taken ? 'Medication Taken' : 'Mark as Taken'}
              </Text>
            </TouchableOpacity>
          </View>
        )}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
     </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
    padding: 20,
  },
  header: {
    fontSize: 24,
    color: '#6A0DAD',
    marginBottom: 20,
    textAlign: 'center',
  },
  calendar: {
    borderWidth: 1,
    borderColor: '#FFF',
    marginBottom: 20,
  },
  medicationCard: {
    backgroundColor: '#6A0DAD',
    padding: 15,
    marginBottom: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  medicationName: {
    fontSize: 18,
    color: '#FFF',
  },
  medicationTime: {
    color: '#D1B3E1',
    marginTop: 5,
  },
  reminderButton: {
    backgroundColor: '#9F7BBF',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  buttonText: {
    color: '#FFF',
    textAlign: 'center',
    fontSize: 16,
  },
});

export default MedicationReminder;

import React, { useState } from 'react';
import { 
  View, 
  Text, 
  Image, 
  TouchableOpacity, 
  StyleSheet, 
  Dimensions, 
  Animated, 
  Easing 
} from 'react-native';
import Swiper from 'react-native-swiper';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const OnboardingScreens = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const navigation = useNavigation();
  const [scale] = useState(new Animated.Value(1));

  const onboardingData = [
    {
      title: 'Real-Time Vitals Monitoring',
      description: 'Track your health metrics instantly and accurately',
      icon: 'https://t4.ftcdn.net/jpg/08/64/76/75/360_F_864767534_qmDLyeV7PjhCa3W0vf1bIixG8Ef56D6u.jpg',
      gradient: ['#662d91', '#662d91']
    },
    {
      title: 'Medication Reminders',
      description: 'Never miss a dose with smart, personalized alerts',
      icon: 'https://creakyjoints.org/wp-content/uploads/2018/11/0918_Medication-Reminder.jpg',
      gradient: ['#DDA0DD', '#DDA0DD']
    },
    {
      title: 'Comprehensive Analytics',
      description: 'Gain insights into your health trends and progress',
      icon: 'https://www.echelonedge.com/wp-content/uploads/2023/04/Big-Data-Analytics.png',
      gradient: ['#720e9e', '#720e9e']
    },
    {
      title: 'Get Started!',
      description: 'Grant permissions to unlock full app functionality',
      icon: 'https://media.istockphoto.com/id/482078816/photo/female-doctorss-hands-holding-stethoscope.jpg?s=612x612&w=0&k=20&c=Mu1mh1_CAT40WVuwl8ljFGXyjbBK5GtaYGVgvOP6hl8=',
      gradient: ['#800080', '#800080']
    }
  ];

  const animateScale = () => {
    Animated.sequence([
      Animated.timing(scale, {
        toValue: 1.1,
        duration: 300,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true
      }),
      Animated.timing(scale, {
        toValue: 1,
        duration: 300,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true
      })
    ]).start();
  };

  return (
    <Swiper
      loop={false}
      showsPagination={true}
      dotColor="rgba(255, 255, 255, 0.5)"
      activeDotColor="white"
      onIndexChanged={(index) => {
        setCurrentPage(index);
        animateScale();
      }}
      paginationStyle={styles.pagination}
      autoplay={true}
      autoplayTimeout={3}
    >
      {onboardingData.map((screen, index) => (
        <Animated.View
          key={index}
          style={[
            styles.slideContainer,
            {
              transform: [{ scale }],
              backgroundColor: screen.gradient[1]
            }
          ]}
        >
          <View style={styles.contentContainer}>
            <Image
              source={{ uri: screen.icon }}
              style={styles.illustration}
              resizeMode="contain"
            />
            <Text style={styles.titleText}>{screen.title}</Text>
            <Text style={styles.descriptionText}>
              {screen.description}
            </Text>
          </View>

          {index === onboardingData.length - 1 && (
            <TouchableOpacity
              style={styles.getStartedButton}
              onPress={() => navigation.navigate('SignupScreen')}
            >
              <Text style={styles.buttonText}>Grant Permissions</Text>
            </TouchableOpacity>
          )}
        </Animated.View>
      ))}
    </Swiper>
  );
};

const styles = StyleSheet.create({
  slideContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20
  },
  contentContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%'
  },
  illustration: {
    width: width * 0.7,
    height: height * 0.4,
    marginBottom: 30,
    borderRadius: 15
  },
  titleText: {
    color: 'white',
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center'
  },
  descriptionText: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 16,
    textAlign: 'center',
    marginHorizontal: 20
  },
  pagination: {
    bottom: 30
  },
  getStartedButton: {
    position: 'absolute',
    bottom: 50,
    backgroundColor: 'white',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
    elevation: 5
  },
  buttonText: {
    color: '#4020A0',
    fontWeight: 'bold',
    fontSize: 16
  }
});

export default OnboardingScreens;

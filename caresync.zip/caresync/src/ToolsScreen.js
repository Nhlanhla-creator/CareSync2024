import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';

const Tools = ({ navigation }) => {
  const handleNavigation = (screen) => {
    navigation.navigate(screen);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Quick Access Tools</Text>

      <View style={styles.toolsContainer}>
        {/* Alerts Section */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('AlertsSection')}
        >
          <MaterialIcons name="notifications" size={30} color="#9C27B0" />
          <Text style={styles.toolText}>Alerts</Text>
        </TouchableOpacity>

        {/* Daily Summary */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('DailySummary')}
        >
          <FontAwesome name="calendar" size={30} color="#D81B60" />
          <Text style={styles.toolText}>Daily Summary</Text>
        </TouchableOpacity>

        {/* Medications */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('MedicationAdherence')}
        >
          <FontAwesome name="medkit" size={30} color="#7B1FA2" />
          <Text style={styles.toolText}>Medications</Text>
        </TouchableOpacity>

        {/* Reminder */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('MedicationReminder')}
        >
          <FontAwesome name="clock" size={30} color="#8E24AA" />
          <Text style={styles.toolText}>Reminder</Text>
        </TouchableOpacity>

        {/* Real-Time Monitoring */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('RealTimeMonitoring')}
        >
          <FontAwesome name="heartbeat" size={30} color="#6A1B9A" />
          <Text style={styles.toolText}>Real-Time Monitoring</Text>
        </TouchableOpacity>

        {/* Vitals */}
        <TouchableOpacity
          style={styles.toolBox}
          onPress={() => handleNavigation('VitalsSection')}
        >
          <FontAwesome name="heartbeat" size={30} color="#9C27B0" />
          <Text style={styles.toolText}>Vitals</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F3E5F5',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#6A1B9A',
    marginBottom: 20,
  },
  toolsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginHorizontal: 10,
  },
  toolBox: {
    backgroundColor: '#D1C4E9',
    borderRadius: 15,
    paddingVertical: 20,
    paddingHorizontal: 15,
    marginVertical: 10,
    width: '48%',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  toolText: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#6A1B9A',
    textAlign: 'center',
  },
});

export default Tools;

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ImageBackground, Image } from 'react-native';

const SplashScreen = ({ navigation }) => {
  useEffect(() => {
    if (navigation) {
      const timer = setTimeout(() => {
        navigation.replace('Onboarding');
      }, 3000); 

      return () => clearTimeout(timer);
    }
  }, [navigation]);

  return (
    <ImageBackground
      source={require('../images/splash.jpg')} 
      style={styles.container}
      resizeMode="cover"
    >
      <View style={styles.logoContainer}>
     
        <Text style={styles.appName}>CareSync</Text>
      
        <Image
          source={require('../images/splash.jpg')} 
          style={styles.logo}
        />
       
        <Text style={styles.tagline}>Empowering Better Care Through Technology</Text>
      </View>
    </ImageBackground>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    marginTop: 20,
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', 
    padding: 20,
    borderRadius: 10,
  },
  appName: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#FFFFFF', 
    marginBottom: 20,
  },
  logo: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
  tagline: {
    marginTop: 10,
    color: '#FFFFFF', 
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
    paddingHorizontal: 30,
  },
});

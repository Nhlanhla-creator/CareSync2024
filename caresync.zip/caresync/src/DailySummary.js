import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView,SafeAreaView } from 'react-native';
import { BarChart, Grid } from 'react-native-svg-charts';

const DailySummary = () => {

  const targetSteps = 8500;
  const targetWater = 2.8; 
  const [currentSteps, setCurrentSteps] = useState(0);
  const [currentWater, setCurrentWater] = useState(0);


  const stepsData = [6500, 7500, targetSteps, 9500, 8000];
  const waterIntakeData = [2, 2.5, targetWater, 2, 2.8];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];


  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentSteps((prev) => {
        if (prev >= targetSteps) {
          clearInterval(stepInterval);
          return targetSteps;
        }
        return prev + Math.ceil(targetSteps / 100); 
      });
    }, 20);

    const waterInterval = setInterval(() => {
      setCurrentWater((prev) => {
        if (prev >= targetWater) {
          clearInterval(waterInterval);
          return targetWater;
        }
        return Math.min(targetWater, prev + 0.02); 
      });
    }, 50);

    return () => {
      clearInterval(stepInterval);
      clearInterval(waterInterval);
    };
  }, [targetSteps, targetWater]);

  return (
    <SafeAreaView style={styles.container}>
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Daily Summary</Text>

   
      <View style={styles.section}>
        <Text style={styles.metricTitle}>Steps Taken</Text>
        <BarChart
          style={styles.chart}
          data={stepsData}
          svg={{ fill: '#A569BD' }}
          contentInset={{ top: 20, bottom: 20 }}
          spacingInner={0.2}
        >
          <Grid />
        </BarChart>
        <Text style={styles.metricLiveCount}>{currentSteps.toLocaleString()} steps</Text>
        <View style={styles.chartLabels}>
          {stepsData.map((steps, index) => (
            <View key={index} style={styles.chartLabel}>
              <Text style={styles.chartLabelDay}>{days[index]}</Text>
              <Text style={styles.chartLabelValue}>{steps.toLocaleString()} steps</Text>
            </View>
          ))}
        </View>
        <Text style={styles.metricSubtext}>Your goal: 10,000 steps/day</Text>
      </View>

  
      <View style={styles.section}>
        <Text style={styles.metricTitle}>Water Intake</Text>
        <BarChart
          style={styles.chart}
          data={waterIntakeData}
          svg={{ fill: '#8E44AD' }}
          contentInset={{ top: 20, bottom: 20 }}
          spacingInner={0.2}
        >
          <Grid />
        </BarChart>
        <Text style={styles.metricLiveCount}>{currentWater.toFixed(2)} L</Text>
        <View style={styles.chartLabels}>
          {waterIntakeData.map((liters, index) => (
            <View key={index} style={styles.chartLabel}>
              <Text style={styles.chartLabelDay}>{days[index]}</Text>
              <Text style={styles.chartLabelValue}>{liters} L</Text>
            </View>
          ))}
        </View>
        <Text style={styles.metricSubtext}>Your goal: 3 liters/day</Text>
      </View>

  
      <View style={styles.section}>
        <Text style={styles.metricTitle}>Other Health Metrics</Text>
        <View style={styles.metricsList}>
          <View style={styles.metricItem}>
            <Text style={styles.metricName}>Sleep</Text>
            <Text style={styles.metricValue}>
              <Text style={styles.highlight}>7.5 hours</Text>
            </Text>
          </View>
          <View style={styles.metricItem}>
            <Text style={styles.metricName}>Calories Burned</Text>
            <Text style={styles.metricValue}>
              <Text style={styles.highlight}>520 kcal</Text>
            </Text>
          </View>
          <View style={styles.metricItem}>
            <Text style={styles.metricName}>Heart Rate</Text>
            <Text style={styles.metricValue}>
              <Text style={styles.highlight}>72 bpm</Text>
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
     </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#5D3FD3',
    textAlign: 'center',
    marginVertical: 16,
  },
  section: {
    marginBottom: 24,
  },
  metricTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6C3483',
    marginBottom: 8,
  },
  chart: {
    height: 150,
    borderRadius: 8,
  },
  metricLiveCount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#9B59B6',
    textAlign: 'center',
    marginVertical: 8,
  },
  metricSubtext: {
    fontSize: 14,
    color: '#7D3C98',
    textAlign: 'center',
    marginTop: 8,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  chartLabel: {
    alignItems: 'center',
  },
  chartLabelDay: {
    fontSize: 14,
    color: '#6C3483',
    fontWeight: 'bold',
  },
  chartLabelValue: {
    fontSize: 12,
    color: '#9B59B6',
  },
  metricsList: {
    marginTop: 8,
  },
  metricItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  metricName: {
    fontSize: 16,
    color: '#5B2C6F',
  },
  metricValue: {
    fontSize: 16,
  },
  highlight: {
    color: '#9B59B6',
    fontWeight: 'bold',
  },
});

export default DailySummary;

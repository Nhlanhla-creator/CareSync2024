import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';
import Animated, { Easing } from 'react-native-reanimated';

const DashboardScreen = () => {
  const [heartRate, setHeartRate] = useState(72);
  const [bloodPressure, setBloodPressure] = useState('120/80');
  const [oxygenLevel, setOxygenLevel] = useState(98);

  const [medications, setMedications] = useState([
    { id: '1', name: 'Aspirin', time: '8:00 AM', status: 'Taken' },
    { id: '2', name: 'Metformin', time: '12:00 PM', status: 'Skipped' },
    { id: '3', name: 'Vitamin D', time: '6:00 PM', status: 'Pending' },
  ]);

  const [alerts, setAlerts] = useState([
    { id: '1', message: 'Heart rate exceeded safe limits (110 bpm)', time: '10:15 AM' },
    { id: '2', message: 'Missed medication: Metformin', time: '12:30 PM' },
  ]);

  const [dailySummary, setDailySummary] = useState({
    steps: 5800,
    waterIntake: 1.5,
    caloriesBurned: 350,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setHeartRate((prev) => prev + Math.floor(Math.random() * 5) - 2);
      setBloodPressure(`${120 + Math.floor(Math.random() * 10)} / ${80 + Math.floor(Math.random() * 10)}`);
      setOxygenLevel((prev) => prev + Math.floor(Math.random() * 3) - 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContainer}>
       
        <View style={styles.welcomeSection}>
          <Image
            source={{ uri: 'https://newprofilepic.photo-cdn.net//assets/images/article/profile.jpg?90af0c8' }} 
            style={styles.profilePicture}
          />
          <Text style={styles.welcomeText}>Welcome, Leece!</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vitals</Text>
          <View style={styles.vitalsContainer}>
            <View style={styles.vitalItem}>
              <FontAwesome name="heartbeat" size={30} color="#FF6F61" />
              <Text style={styles.vitalText}>{heartRate} bpm</Text>
              <Text style={styles.vitalLabel}>Heart Rate</Text>
            </View>
            <View style={styles.vitalItem}>
              <MaterialIcons name="bloodtype" size={30} color="#9C27B0" />
              <Text style={styles.vitalText}>{bloodPressure}</Text>
              <Text style={styles.vitalLabel}>Blood Pressure</Text>
            </View>
            <View style={styles.vitalItem}>
              <FontAwesome name="tint" size={30} color="#BA68C8" />
              <Text style={styles.vitalText}>{oxygenLevel}%</Text>
              <Text style={styles.vitalLabel}>Oxygen Level</Text>
            </View>
          </View>
        </View>

    
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Medications</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
            {medications.map((medication) => (
              <TouchableOpacity key={medication.id} style={styles.medicationCard}>
                <Text style={styles.medicationName}>{medication.name}</Text>
                <Text style={styles.medicationTime}>{medication.time}</Text>
                <Text style={[styles.medicationStatus, styles[`status${medication.status}`]]}>
                  {medication.status}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

      
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Alerts</Text>
          {alerts.map((alert) => (
            <View key={alert.id} style={styles.alertCard}>
              <Text style={styles.alertMessage}>{alert.message}</Text>
              <Text style={styles.alertTime}>{alert.time}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Daily Summary</Text>
          <View style={styles.summaryContainer}>
            <View style={styles.summaryItem}>
              <FontAwesome name="feet" size={30} color="#AB47BC" />
              <Text style={styles.summaryText}>{dailySummary.steps} steps</Text>
            </View>
            <View style={styles.summaryItem}>
              <FontAwesome name="tint" size={30} color="#8E24AA" />
              <Text style={styles.summaryText}>{dailySummary.waterIntake} L</Text>
            </View>
            <View style={styles.summaryItem}>
              <FontAwesome name="fire" size={30} color="#D81B60" />
              <Text style={styles.summaryText}>{dailySummary.caloriesBurned} kcal</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
  },
  scrollContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  welcomeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#EDE7F6',
  },
  profilePicture: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  welcomeText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6A1B9A',
  },
  section: {
    marginVertical: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#6A1B9A',
    borderBottomWidth: 2,
    borderColor: '#D81B60',
  },
  vitalsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  vitalItem: {
    alignItems: 'center',
  },
  vitalText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6A1B9A',
  },
  vitalLabel: {
    fontSize: 14,
    color: '#7B1FA2',
  },
  horizontalScroll: {
    paddingVertical: 10,
  },
  medicationCard: {
    backgroundColor: '#F8BBD0',
    padding: 15,
    borderRadius: 10,
    marginRight: 10,
    width: 150,
    alignItems: 'center',
  },
  medicationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4A148C',
  },
  medicationTime: {
    fontSize: 14,
    color: '#880E4F',
    marginVertical: 5,
  },
  medicationStatus: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  alertCard: {
    backgroundColor: '#F8BBD0',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  alertMessage: {
    fontSize: 14,
    color: '#C2185B',
    fontWeight: 'bold',
  },
  alertTime: {
    fontSize: 12,
    color: '#AD1457',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#6A1B9A',
    marginTop: 5,
  },
});

export default DashboardScreen;

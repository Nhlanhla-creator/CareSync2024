import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView ,SafeAreaView} from 'react-native';
import { Card } from 'react-native-paper';
import { LineChart } from 'react-native-chart-kit';


const generateRandomVitals = () => {
  return {
    heartRate: Math.floor(Math.random() * (120 - 60 + 1) + 60), 
    systolic: Math.floor(Math.random() * (160 - 90 + 1) + 90), 
    diastolic: Math.floor(Math.random() * (120 - 60 + 1) + 60), 
    oxygenLevel: Math.floor(Math.random() * (100 - 90 + 1) + 90), 
  };
};

const VitalsSection = () => {
  const [vitals, setVitals] = useState(generateRandomVitals());
  const [history, setHistory] = useState({
    heartRate: [],
    systolic: [],
    diastolic: [],
    oxygenLevel: [],
  });

 
  useEffect(() => {
    const interval = setInterval(() => {
      const newVitals = generateRandomVitals();
      setVitals(newVitals);
      setHistory((prevState) => ({
        heartRate: [...prevState.heartRate, newVitals.heartRate].slice(-10),
        systolic: [...prevState.systolic, newVitals.systolic].slice(-10),
        diastolic: [...prevState.diastolic, newVitals.diastolic].slice(-10),
        oxygenLevel: [...prevState.oxygenLevel, newVitals.oxygenLevel].slice(-10),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);


  const getStatusColor = (value, type) => {
    switch (type) {
      case 'heartRate':
        return value < 60 ? 'red' : value > 100 ? 'red' : 'green';
      case 'bp':
        return value > 140 ? 'red' : value < 90 ? 'red' : 'green';
      case 'oxygen':
        return value < 95 ? 'red' : 'green';
      default:
        return 'green';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
    <ScrollView style={styles.container}>
   
      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Heart Rate</Text>
        <Text
          style={[styles.value, { color: getStatusColor(vitals.heartRate, 'heartRate') }]}
        >
          {vitals.heartRate} bpm
        </Text>
        <LineChart
          data={{
            labels: Array(history.heartRate.length).fill(''),
            datasets: [{ data: history.heartRate }],
          }}
          width={350}
          height={220}
          chartConfig={{
            backgroundColor: '#6A0DAD',
            backgroundGradientFrom: '#6A0DAD',
            backgroundGradientTo: '#9F7BBF',
            decimalPlaces: 0,
            color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            style: { borderRadius: 16 },
          }}
          style={styles.chart}
        />
      </Card>

  
      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Blood Pressure</Text>
        <Text
          style={[styles.value, { color: getStatusColor(vitals.systolic, 'bp') }]}
        >
          {vitals.systolic}/{vitals.diastolic} mmHg
        </Text>
        <LineChart
          data={{
            labels: Array(history.systolic.length).fill(''),
            datasets: [{ data: history.systolic }],
          }}
          width={350}
          height={220}
          chartConfig={{
            backgroundColor: '#6A0DAD',
            backgroundGradientFrom: '#6A0DAD',
            backgroundGradientTo: '#9F7BBF',
            decimalPlaces: 0,
            color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            style: { borderRadius: 16 },
          }}
          style={styles.chart}
        />
      </Card>


      <Card style={styles.card}>
        <Text style={styles.cardTitle}>Oxygen Level</Text>
        <Text
          style={[styles.value, { color: getStatusColor(vitals.oxygenLevel, 'oxygen') }]}
        >
          {vitals.oxygenLevel}%
        </Text>
        <LineChart
          data={{
            labels: Array(history.oxygenLevel.length).fill(''),
            datasets: [{ data: history.oxygenLevel }],
          }}
          width={350}
          height={220}
          chartConfig={{
            backgroundColor: '#6A0DAD',
            backgroundGradientFrom: '#6A0DAD',
            backgroundGradientTo: '#9F7BBF',
            decimalPlaces: 0,
            color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
            style: { borderRadius: 16 },
          }}
          style={styles.chart}
        />
      </Card>
    </ScrollView>
     </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
    padding: 20,
  },
  card: {
    marginBottom: 20,
    borderRadius: 10,
    backgroundColor: '#6A0DAD',
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  cardTitle: {
    fontSize: 20,
    color: '#FFF',
    marginBottom: 10,
  },
  value: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFF',
  },
  chart: {
    marginTop: 15,
    borderRadius: 16,
  },
});

export default VitalsSection;

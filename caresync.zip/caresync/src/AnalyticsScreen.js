import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity,SafeAreaView } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const screenWidth = Dimensions.get('window').width;

const InsightsAnalyticsScreen = () => {
 
  const weeklyVitals = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        data: [72, 75, 70, 78, 74, 76, 73], 
        color: (opacity = 1) => `rgba(233, 30, 99, ${opacity})`, 
      },
      {
        data: [120, 118, 122, 121, 119, 117, 120], 
        color: (opacity = 1) => `rgba(63, 81, 181, ${opacity})`, 
      },
    ],
  };

  const aiSuggestions = [
    { id: '1', suggestion: 'Increase daily water intake to at least 2.5 liters.' },
    { id: '2', suggestion: 'Maintain a consistent sleep schedule for better recovery.' },
    { id: '3', suggestion: 'Regularly monitor your blood pressure levels in the evening.' },
  ];

  return (
    <SafeAreaView style={styles.container}>
    <ScrollView style={styles.container}>
      {/* Insights Header */}
      <Text style={styles.title}>Health Insights & Analytics</Text>

      {/* Weekly Trends */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Weekly Trends</Text>
        <LineChart
          data={weeklyVitals}
          width={screenWidth - 40}
          height={220}
          chartConfig={{
            backgroundColor: '#fff',
            backgroundGradientFrom: '#D1C4E9',
            backgroundGradientTo: '#BA68C8',
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            style: { borderRadius: 16 },
          }}
          bezier
          style={styles.graphStyle}
        />
      </View>

  
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Monthly Trends</Text>
        <LineChart
          data={{
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [
              {
                data: [68, 72, 74, 71], 
                color: (opacity = 1) => `rgba(76, 175, 80, ${opacity})`, 
              },
            ],
          }}
          width={screenWidth - 40}
          height={220}
          chartConfig={{
            backgroundColor: '#fff',
            backgroundGradientFrom: '#F3E5F5',
            backgroundGradientTo: '#CE93D8',
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            style: { borderRadius: 16 },
          }}
          bezier
          style={styles.graphStyle}
        />
      </View>


      <View style={styles.section}>
        <Text style={styles.sectionTitle}>AI Suggestions</Text>
        {aiSuggestions.map((item) => (
          <View key={item.id} style={styles.suggestionCard}>
            <MaterialIcons name="lightbulb" size={24} color="#FFEB3B" />
            <Text style={styles.suggestionText}>{item.suggestion}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
     </SafeAreaView>
  );
};

export default InsightsAnalyticsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6A1B9A',
    textAlign: 'center',
    marginBottom: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6A1B9A',
    marginBottom: 10,
    borderBottomWidth: 2,
    borderColor: '#D81B60',
  },
  graphStyle: {
    marginVertical: 10,
    borderRadius: 16,
  },
  suggestionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EDE7F6',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  suggestionText: {
    fontSize: 14,
    color: '#4A148C',
    marginLeft: 10,
  },
});

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { GestureHandlerRootView, PanGestureHandler } from 'react-native-gesture-handler';
import Animated from 'react-native-reanimated';

const SignupScreen = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showOTP, setShowOTP] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    email: '',
    password: '',
    confirmPassword: '',
    otp: '',
  });

  const navigation = useNavigation();

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password) => password.length >= 8;

  const handleSubmit = () => {
    if (isSignUp) {
      if (!formData.name.trim()) {
        Alert.alert('Error', 'Please enter your name');
        return;
      }
      if (!formData.age.trim() || isNaN(formData.age)) {
        Alert.alert('Error', 'Please enter a valid age');
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        Alert.alert('Error', 'Passwords do not match');
        return;
      }
    }

    if (!validateEmail(formData.email)) {
      Alert.alert('Error', 'Please enter a valid email');
      return;
    }
    if (!validatePassword(formData.password)) {
      Alert.alert('Error', 'Password must be at least 8 characters');
      return;
    }

    setShowOTP(true);
  };

  const verifyOTP = () => {
    if (formData.otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }

    Alert.alert('Success', 'Authentication successful!');
    navigation.replace('Setup');
  };

  const renderOTPScreen = () => (
    <View style={styles.formContainer}>
      <Text style={styles.title}>Verify OTP</Text>
      <Text style={styles.subtitle}>Enter the 6-digit code sent to your email</Text>
      <View style={styles.otpContainer}>
        <TextInput
          style={styles.otpInput}
          value={formData.otp}
          onChangeText={(value) => handleInputChange('otp', value)}
          keyboardType="number-pad"
          maxLength={6}
          placeholder="Enter OTP"
          placeholderTextColor="#A0A0A0"
        />
      </View>
      <TouchableOpacity style={styles.button} onPress={verifyOTP}>
        <Text style={styles.buttonText}>Verify OTP</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.linkButton} onPress={() => setShowOTP(false)}>
        <Text style={styles.linkText}>Back to {isSignUp ? 'Sign Up' : 'Sign In'}</Text>
      </TouchableOpacity>
    </View>
  );

  const renderAuthForm = () => (
    <View style={styles.formContainer}>
      <Text style={styles.title}>{isSignUp ? 'Create Account' : 'Welcome Back'}</Text>
      <Text style={styles.subtitle}>{isSignUp ? 'Sign up to get started' : 'Sign in to continue'}</Text>
      {isSignUp && (
        <>
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            placeholderTextColor="#A0A0A0"
            value={formData.name}
            onChangeText={(value) => handleInputChange('name', value)}
          />
          <TextInput
            style={styles.input}
            placeholder="Age"
            placeholderTextColor="#A0A0A0"
            keyboardType="number-pad"
            value={formData.age}
            onChangeText={(value) => handleInputChange('age', value)}
          />
        </>
      )}
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#A0A0A0"
        keyboardType="email-address"
        autoCapitalize="none"
        value={formData.email}
        onChangeText={(value) => handleInputChange('email', value)}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#A0A0A0"
        secureTextEntry
        value={formData.password}
        onChangeText={(value) => handleInputChange('password', value)}
      />
      {isSignUp && (
        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          placeholderTextColor="#A0A0A0"
          secureTextEntry
          value={formData.confirmPassword}
          onChangeText={(value) => handleInputChange('confirmPassword', value)}
        />
      )}
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.linkButton} onPress={() => setIsSignUp(!isSignUp)}>
        <Text style={styles.linkText}>
          {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <GestureHandlerRootView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <PanGestureHandler
            onGestureEvent={(event) => {
              if (event.nativeEvent.translationX < -100) {
                setIsSignUp(false);
              } else if (event.nativeEvent.translationX > 100) {
                setIsSignUp(true);
              }
            }}
          >
            <Animated.View>{showOTP ? renderOTPScreen() : renderAuthForm()}</Animated.View>
          </PanGestureHandler>
        </ScrollView>
      </KeyboardAvoidingView>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F9F9F9' },
  scrollContent: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  formContainer: { width: '100%', maxWidth: 400, alignSelf: 'center' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#6A1B9A', marginBottom: 10, textAlign: 'center' },
  subtitle: { fontSize: 16, color: '#666', marginBottom: 20, textAlign: 'center' },
  input: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  otpContainer: { alignItems: 'center', marginBottom: 20 },
  otpInput: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 10,
    fontSize: 24,
    width: '60%',
    textAlign: 'center',
    letterSpacing: 5,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  button: { backgroundColor: '#6A1B9A', padding: 15, borderRadius: 10, alignItems: 'center', marginTop: 10 },
  buttonText: { color: '#FFF', fontSize: 18, fontWeight: 'bold' },
  linkButton: { marginTop: 20, alignItems: 'center' },
  linkText: { color: '#6C63FF', fontSize: 16 },
});

export default SignupScreen;

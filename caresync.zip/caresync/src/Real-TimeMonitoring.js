import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Alert, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Animated, { Easing } from 'react-native-reanimated';

const RealTimeMonitoring = () => {
  const [heartRate, setHeartRate] = useState(72);
  const [oxygenLevel, setOxygenLevel] = useState(98);
  const [temperature, setTemperature] = useState(36.5);

  useEffect(() => {
    const heartRateInterval = setInterval(() => {
      const newRate = Math.floor(60 + Math.random() * 40);
      setHeartRate(newRate);
      checkThresholds("Heart Rate", newRate, 60, 100);
    }, 3000);

    const oxygenInterval = setInterval(() => {
      const newOxygen = (95 + Math.random() * 5).toFixed(1);
      setOxygenLevel(parseFloat(newOxygen));
      checkThresholds("Oxygen Level", newOxygen, 95, 100);
    }, 5000);

    const tempInterval = setInterval(() => {
      const newTemp = (36 + Math.random() * 1.5).toFixed(1);
      setTemperature(parseFloat(newTemp));
      checkThresholds("Temperature", newTemp, 36, 37.5);
    }, 4000);

    return () => {
      clearInterval(heartRateInterval);
      clearInterval(oxygenInterval);
      clearInterval(tempInterval);
    };
  }, []);

  const checkThresholds = (metric, value, min, max) => {
    if (value < min || value > max) {
      Alert.alert(
        "⚠️ Alert",
        `${metric} is abnormal: ${value}`,
        [{ text: "OK", style: "cancel" }],
        { cancelable: true }
      );
    }
  };

  const handleEmergency = () => {
    Alert.alert(
      "🚨 Emergency",
      "Calling the nearest hospital or caregiver...",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Proceed", onPress: () => console.log("Calling emergency services...") },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container}>
        <Text style={styles.title}>🌡️ Real-Time Monitoring</Text>

        <View style={[styles.metricContainer, { borderColor: heartRate > 100 || heartRate < 60 ? '#E74C3C' : '#2ECC71' }]}>
          <Text style={styles.metricName}>💓 Heart Rate</Text>
          <Animated.Text style={[styles.metricValue, { color: heartRate > 100 || heartRate < 60 ? '#E74C3C' : '#2ECC71' }]}>
            {heartRate} bpm
          </Animated.Text>
        </View>

        <View style={[styles.metricContainer, { borderColor: oxygenLevel < 95 ? '#E74C3C' : '#3498DB' }]}>
          <Text style={styles.metricName}>🫁 Oxygen Level</Text>
          <Animated.Text style={[styles.metricValue, { color: oxygenLevel < 95 ? '#E74C3C' : '#3498DB' }]}>
            {oxygenLevel}%
          </Animated.Text>
        </View>

        <View style={[styles.metricContainer, { borderColor: temperature > 37.5 || temperature < 36 ? '#E74C3C' : '#F1C40F' }]}>
          <Text style={styles.metricName}>🌡️ Temperature</Text>
          <Animated.Text style={[styles.metricValue, { color: temperature > 37.5 || temperature < 36 ? '#E74C3C' : '#F1C40F' }]}>
            {temperature}°C
          </Animated.Text>
        </View>

        <TouchableOpacity style={styles.emergencyButton} onPress={handleEmergency}>
          <Ionicons name="alert-circle" size={24} color="#fff" />
          <Text style={styles.emergencyButtonText}>Emergency</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#34495E',
    textAlign: 'center',
    marginVertical: 16,
  },
  metricContainer: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    borderWidth: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  metricName: {
    fontSize: 20,
    color: '#7F8C8D',
  },
  metricValue: {
    fontSize: 36,
    fontWeight: 'bold',
    marginTop: 8,
  },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#E74C3C',
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 32,
    elevation: 5,
  },
  emergencyButtonText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 8,
  },
});

export default RealTimeMonitoring;

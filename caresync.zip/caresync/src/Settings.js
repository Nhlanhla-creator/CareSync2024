import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch, Alert, SafeAreaView, Image, ScrollView } from 'react-native';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';

const SettingsScreen = () => {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  const handleExportData = (format) => {
    Alert.alert(`Data Exported`, `Your data has been exported as a ${format} file.`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
     
        <View style={styles.profileSection}>
          <Image
            source={{ uri: 'https://newprofilepic.photo-cdn.net//assets/images/article/profile.jpg?90af0c8' }}
            style={styles.profilePicture}
          />
          <View>
            <Text style={styles.profileName}>Leece</Text>
            <Text style={styles.profileEmail}>leece@example.com</Text>
          </View>
        </View>

       
        <TouchableOpacity style={styles.option}>
          <FontAwesome name="user-circle" size={24} color="#6A1B9A" />
          <Text style={styles.optionText}>Update Personal Details</Text>
          <MaterialIcons name="arrow-forward-ios" size={20} color="#777" />
        </TouchableOpacity>

        <View style={styles.option}>
          <FontAwesome name="bell" size={24} color="#6A1B9A" />
          <Text style={styles.optionText}>Notification Preferences</Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={(value) => setNotificationsEnabled(value)}
            trackColor={{ false: '#ccc', true: '#BA68C8' }}
            thumbColor={notificationsEnabled ? '#6A1B9A' : '#f4f3f4'}
          />
        </View>

        <View style={styles.option}>
          <MaterialIcons name="palette" size={24} color="#6A1B9A" />
          <Text style={styles.optionText}>Appearance</Text>
          <Switch
            value={darkMode}
            onValueChange={(value) => setDarkMode(value)}
            trackColor={{ false: '#ccc', true: '#BA68C8' }}
            thumbColor={darkMode ? '#6A1B9A' : '#f4f3f4'}
          />
        </View>

  
        <View style={styles.optionGroup}>
          <Text style={styles.groupTitle}>Security</Text>
          <TouchableOpacity style={styles.option}>
            <FontAwesome name="lock" size={24} color="#6A1B9A" />
            <Text style={styles.optionText}>Change Password</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.option}>
            <MaterialIcons name="security" size={24} color="#6A1B9A" />
            <Text style={styles.optionText}>Two-Factor Authentication</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.optionGroup}>
          <Text style={styles.groupTitle}>Export Data</Text>
          <TouchableOpacity
            style={styles.exportButton}
            onPress={() => handleExportData('PDF')}
          >
            <Text style={styles.exportButtonText}>Export as PDF</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.exportButton}
            onPress={() => handleExportData('CSV')}
          >
            <Text style={styles.exportButtonText}>Export as CSV</Text>
          </TouchableOpacity>
        </View>


        <View style={styles.optionGroup}>
          <Text style={styles.groupTitle}>App Info</Text>
          <TouchableOpacity style={styles.option}>
            <MaterialIcons name="info" size={24} color="#6A1B9A" />
            <Text style={styles.optionText}>About App</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.option}>
            <MaterialIcons name="gavel" size={24} color="#6A1B9A" />
            <Text style={styles.optionText}>Terms & Privacy</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SettingsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: '#EDE7F6',
    padding: 15,
    borderRadius: 10,
  },
  profilePicture: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  profileName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6A1B9A',
  },
  profileEmail: {
    fontSize: 14,
    color: '#7B1FA2',
  },
  option: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#EDE7F6',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  optionText: {
    fontSize: 16,
    color: '#4A148C',
    flex: 1,
    marginLeft: 10,
  },
  optionGroup: {
    marginTop: 25,
  },
  groupTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6A1B9A',
    marginBottom: 15,
    borderBottomWidth: 1.5,
    borderColor: '#BA68C8',
    paddingBottom: 10,
  },
  exportButton: {
    backgroundColor: '#BA68C8',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  exportButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
});

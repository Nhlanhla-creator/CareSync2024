import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, SafeAreaView } from 'react-native';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';

const PatientDetailsScreen = () => {
  const patientInfo = {
    name: 'Leece',
    age: 20,
    gender: 'Female',
    profilePicture: 'https://newprofilepic.photo-cdn.net//assets/images/article/profile.jpg?90af0c8',
  };

  const healthHistory = [
    { id: '1', date: '2023-11-15', event: 'Routine checkup - All vitals normal.' },
    { id: '2', date: '2023-11-10', event: 'Diagnosed with hypertension.' },
    { id: '3', date: '2023-10-20', event: 'Admitted for chest pain - Discharged same day.' },
  ];

  const medications = [
    { id: '1', name: 'Aspirin', adherence: '80%' },
    { id: '2', name: 'Metformin', adherence: '60%' },
    { id: '3', name: 'Vitamin D', adherence: '95%' },
  ];

  const [notes, setNotes] = useState([
    { id: '1', text: 'Monitor blood pressure regularly.' },
    { id: '2', text: 'Advise patient to increase physical activity.' },
  ]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.card}>
        <View style={styles.profileSection}>
          <Image source={{ uri: patientInfo.profilePicture }} style={styles.profilePicture} />
          <View style={styles.basicInfo}>
            <Text style={styles.name}>{patientInfo.name}</Text>
            <Text style={styles.info}>Age: {patientInfo.age}</Text>
            <Text style={styles.info}>Gender: {patientInfo.gender}</Text>
          </View>
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          <MaterialIcons name="history" size={20} color="#6A1B9A" /> Health History
        </Text>
        <FlatList
          data={healthHistory}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.historyItem}>
              <Text style={styles.historyDate}>{item.date}</Text>
              <Text style={styles.historyEvent}>{item.event}</Text>
            </View>
          )}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          <FontAwesome name="medkit" size={20} color="#6A1B9A" /> Medications
        </Text>
        <FlatList
          data={medications}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.medicationItem}>
              <Text style={styles.medicationName}>{item.name}</Text>
              <Text style={styles.medicationAdherence}>Adherence: {item.adherence}</Text>
            </View>
          )}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.sectionTitle}>
          <FontAwesome name="sticky-note" size={20} color="#6A1B9A" /> Notes
        </Text>
        <FlatList
          data={notes}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.noteItem}>
              <Text style={styles.noteText}>{item.text}</Text>
            </View>
          )}
        />
        <TouchableOpacity style={styles.floatingButton}>
          <FontAwesome name="plus" size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default PatientDetailsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3E5F5',
    padding: 16,
  },
  card: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  basicInfo: {
    justifyContent: 'center',
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#6A1B9A',
  },
  info: {
    fontSize: 16,
    color: '#7B1FA2',
    marginTop: 5,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6A1B9A',
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  historyItem: {
    backgroundColor: '#F8BBD0',
    padding: 10,
    borderRadius: 10,
    marginBottom: 8,
  },
  historyDate: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#880E4F',
  },
  historyEvent: {
    fontSize: 14,
    color: '#4A148C',
    marginTop: 4,
  },
  medicationItem: {
    backgroundColor: '#EDE7F6',
    padding: 10,
    borderRadius: 10,
    marginBottom: 8,
  },
  medicationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#6A1B9A',
  },
  medicationAdherence: {
    fontSize: 14,
    color: '#7B1FA2',
    marginTop: 4,
  },
  noteItem: {
    backgroundColor: '#D1C4E9',
    padding: 10,
    borderRadius: 10,
    marginBottom: 8,
  },
  noteText: {
    fontSize: 14,
    color: '#4A148C',
  },
  floatingButton: {
    backgroundColor: '#BA68C8',
    width: 50,
    height: 50,
    borderRadius: 25,
    position: 'absolute',
    right: 20,
    bottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 5,
  },
});
